<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ProcutController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->model('Authentication');
        $this->load->model('common/ProductModel');
    }

// this function is work when click on product-page and get access on page productpage
    public function index()
    {
        $this->load->view('product_record/showingdata');
    }

    // this function perfom to get dropdown values on users table

    public function addrecord()
    {
        $this->load->model('common/ProductModel');
        $page_data['get_user'] = $this->ProductModel->getusers();
        $this->load->view('product_record/addrecord', $page_data);
    }

    //this function insert the data into data base
    public function saverecord()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('item', 'Item', 'required');
        $this->form_validation->set_rules('price', 'price', 'required');
        if ($this->form_validation->run() == false) {
            // if our information is failed the call the index function
            $this->index();
            // for insert data through array values and putin this mathod in UserModel
        } else {
            $data = array(
                'name' => $this->input->post('name'),
                'item' => $this->input->post('item'),
                'price' => $this->input->post('price'),

            );
            $this->load->database();
            $record_user = new ProductModel;
            $checking = $record_user->recordUser($data);

            if ($checking) {
                $this->session->set_flashdata('status', 'Record Save successfully');
                redirect(base_url('showingdata'));
            } else {
                $this->session->set_flashdata('status', 'Something Went Wrong');
                redirect(base_url('addrecord'));
            }
        }
    }

    //this function use for mainpage redirect
    public function showingdata()
    {
        $this->load->model('ProductModel');
        $record_data['record'] = $this->ProductModel->showdata();
        $this->load->view('product_record/showingdata', $record_data);

    }
    //this function edit the data into data base dont tuch again

    public function editrecord($product_id)
    {
        $this->load->model('ProductModel');
        $data['record'] = $this->ProductModel->editproduct($product_id);
        $this->load->view('product_record/editrecord', $data);

    }

    // is only for get dropdown value in editrecord page

    public function dropvalues()
    {
        $this->load->model('ProductModel');
        $page_data['list'] = $this->ProductModel->valuesdrop();
        $this->load->view('product_record/editrecord', $page_data);
    }

    // this function update the record

    public function update($product_id)
    {
        $data = [
            // 'user_name' => $this->input->post('user_name'),
            'item' => $this->input->post('item'),
            'price' => $this->input->post('price'),
        ];

        $this->load->model('ProductModel');
        $result = $this->ProductModel->updatepage($data, $product_id);
        if ($result) {
            $this->session->set_flashdata('status', 'your recod updated successfully.!');
            redirect(base_url('showingdata'));
        } else {
            $this->editrecord($product_id);
        }
    }
    //this function delete the record

    public function delete($id)
    {
        $this->load->model('common/ProductModel');
        $result = $this->ProductModel->daletepage($id);
        if ($result) {
            $this->session->set_flashdata('status', 'Record Deleted successfully.!');
            redirect(base_url('showingdata'));
        } else {
            $this->edit($id);
        }
    }
}
