<?php
defined('BASEPATH') or exit('No direct script access allowed');

class LoginController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->has_userdata('authenticated')) {
            $this->session->set_flashdata('status', 'you are already logged in.!');
            redirect(base_url('homepage'));
        }

        $this->load->helper('form');
        $this->load->library('form_validation');

        // Include Model file here
        $this->load->model('UserModel');
    }
    public function index()
    {
        $this->load->view('login_panel/login');
    }

    public function login()
    {
        $this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        if ($this->form_validation->run() == false) {

            // fails
            $this->index();
        } else {
            $data = [
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
            ];

            $user = new UserModel;
            $result = $user->loginUser($data);

            if ($result != false) {

                // check authentication or not
                $auth_userdetails = [
                    'user_name' => $result->user_name,
                    'email' => $result->email,
                ];

                // 1 is operate for users
                $this->session->set_userdata('authenticated', '1');
                $session_data = $this->session->set_userdata($auth_userdetails);

                $this->session->set_flashdata('status', 'you are logged in successfully');
                redirect(base_url('homepage'));
            } else {
                $this->session->set_flashdata('status', 'Invalid Email id or Password');
                redirect(base_url('login'));
            }
        }
    }
}
