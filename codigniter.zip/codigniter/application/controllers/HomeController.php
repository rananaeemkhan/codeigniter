<?php
defined('BASEPATH') or exit('No direct script access allowed');

class HomeController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Authentication');
    }
    // for home page data
    public function index()
    {
        $this->load->view('login_panel/homepage');
    }

    // function for fetch all data

    public function userpage()
    {
        $this->load->model('UserModel');
        $data['homepage'] = $this->UserModel->gethomepage();
        $this->load->view('login_panel/userpage', $data);
    }

    // function for edit the data

    public function edit($id)
    {
        $this->load->model('UserModel');
        $data['edit'] = $this->UserModel->editpage($id);
        $this->load->view('login_panel/edit', $data);

    }

    // Update Function

    public function update($id)
    {
        $data = [
            'user_name' => $this->input->post('user_name'),
            'email' => $this->input->post('email'),
        ];

        $this->load->model('UserModel');
        $result = $this->UserModel->updatepage($data, $id);
        if ($result) {
            $this->session->set_flashdata('status', 'your recod updated successfully.!');
            redirect(base_url('userpage'));
        } else {
            $this->edit($id);
        }
    }
    public function delete($id)
    {
        $this->load->model('UserModel');
        $result = $this->UserModel->daletepage($id);
        if ($result) {
            $this->session->set_flashdata('status', 'Record Deleted successfully.!');
            redirect(base_url('userpage'));
        } else {
            $this->edit($id);
        }
    }
}
