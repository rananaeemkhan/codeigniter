<?php
defined('BASEPATH') or exit('No direct script access allowed');

class RegisterController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->has_userdata('authenticated')) {
            $this->session->set_flashdata('status', 'you are already logged in.!');
            redirect(base_url('userpage'));
        }
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->load->model('UserModel');
    }
    public function index()
    {
        $this->load->view('login_panel/register');
    }
    public function register()
    {
        $this->form_validation->set_rules('user_name', 'User Name', 'required');
        $this->form_validation->set_rules('email', 'Email Id', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'password', 'trim|required');
        $this->form_validation->set_rules('cpassword', 'Confirm password', 'trim|required|matches[password]');
        if ($this->form_validation->run() == false) {
            // if our information is failed the call the index function

            $this->index();
            // for insert data through array values and putin this mathod in UserModel
        } else {
            $data = array(
                'user_name' => $this->input->post('user_name'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
            );

            $register_user = new UserModel;
            $checking = $register_user->registerUser($data);
            if ($checking) {
                $this->session->set_flashdata('status', 'You have successfully registered');
                redirect(base_url('login'));
            } else {
                $this->session->set_flashdata('status', 'Something Went Wrong');
                redirect(base_url('register'));
            }
        }
    }
}
