<?php
// defined('BASEPATH') or exit('No direct script access allowed');

// class EditController extends CI_Controller
// {
//     public function __construct()
//     {
//         parent::__construct();

//         $this->load->model('Authentication');
//     }
//     public function index()
//     {
//         $this->load->view('login_panel/edit');
//     }
//     public function edit($id)
//     {
//         $this->load->model('UserModel');
//         $data = $this->UserModel->editpage($id);
//         $this->load->view('login_panel/edit', $data);
//     }

// }
