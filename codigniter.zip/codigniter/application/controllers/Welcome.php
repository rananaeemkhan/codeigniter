<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

// class Welcome Method index just for understanding
    public function index()
    {
        $this->load->view('welcome_message');
    }
}
