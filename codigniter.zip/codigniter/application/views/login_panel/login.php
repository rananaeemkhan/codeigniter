<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>

<div class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col md-5">
        <?php if ($this->session->flashdata('status')): ?>
            <div class="alert alert-success">
                <?=$this->session->flashdata('status');?>
            </div>
        <?php endif?>
        <div class="card shadow">
          <div class="card-header">
            <h5>Login Form</h5>
          </div>
          <div class="card-body">
            <form action="<?php echo base_url('login') ?>" method="POST">
             <div class="col-md-12">
             <div class="form-group">
                <label for="">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Email Address">
                <small><?php echo form_error('email'); ?></small>
              </div>
             </div>
             <div class="col-md-12">
                <div class="form-group">
                  <label for="">Password</label>
                  <input type="password" name="password" class="form-control" placeholder="Enter your password">
                  <small><?php echo form_error('password'); ?></small>
                </div>
             </div>
              <hr>
              <div class="row">
                <div class="col-lg-12 d-flex">
                <div class="col-md-5">
                <div class="form-group">
                  <button type="submit" class="btn btn-success">Login Now</button>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="register" class="link-danger">Register</a></p>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group px-5">
                  <p class="small fw-bold mt-2 pt-1 mb-0"><a href="#!" class="link-danger">Forgot password?</a></p>
                </div>
              </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>