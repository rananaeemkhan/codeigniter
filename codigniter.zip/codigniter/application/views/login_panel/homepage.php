<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>
<div class="py5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 pt-2">
                <?php if ($this->session->flashdata('status')): ?>
                    <div class="alert alert-success">
                        <?=$this->session->flashdata('status');?>
                    </div>
                <?php endif?>
                <div class="card">
                    <div class="card-header">
                        <h5>User Page</h5>
                    </div>
                    <div class="card-body">
                        <h6>You are in user Home Pge</h6>
                        <h5>User Name:<?php echo $this->session->userdata('user_name'); ?><h5>
                        <h5>Email:<?php echo $this->session->userdata('email'); ?><h5>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h2 class="text-center text-info">Welcome <?php echo $this->session->userdata('user_name'); ?> on dashborad</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
