<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-10">
                                <h5>Edit/Update Register Reord</h5>
                            </div>
                            <div class="col-md-2 px-4">
                                <a href="<?php echo base_url('userpage'); ?>" class="btn btn-info btn-sm">Back</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url('HomeController/update/' . $edit->id) ?>" method="POST">

                        <div class="row">
                        <div class="col-md-12 mb-1">
                                <div class="form-group">
                                    <label for="" class="bg-secondary text-light" style="padding: 0px 10px 0px 10px;">Id=<?=$edit->id?></label>
                                </div>
                            </div>
                            <hr>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">First Name</label>
                                    <input type="text" name="user_name" class="form-control" value="<?=$edit->user_name?>">
                                    <small><?php echo form_error('user_name'); ?></small>
                                </div>
                            </div>
                            <div class="col-md-12 mb-4">
                                <div class="form-group">
                                    <label for="">Email Address</label>
                                    <input type="email" name="email" class="form-control" value="<?=$edit->email?>">
                                    <small><?php echo form_error('email'); ?></small>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success btn-lg">Update</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

