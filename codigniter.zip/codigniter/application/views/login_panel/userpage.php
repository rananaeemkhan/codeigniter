<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>

<div class="py5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="row">
                    <div class="col-md-3"><h5>User Data</h5></div>
                        <div class="col-md-9">
                            <?php if ($this->session->flashdata('status')): ?>
                                <div class="alert alert-success">
                                    <?=$this->session->flashdata('status');?>
                                </div>
                            <?php endif?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
<?php foreach ($homepage as $row): ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo $row->user_name; ?></td>
                                <td><?php echo $row->email; ?></td>
                                <td>
                                <a href="<?php echo base_url('homecontroller/edit/' . $row->id); ?>"
                                 class="btn btn-warning btn-sm">Edit</a>
                                </td>
                                <td>
                                    <a href="<?php echo base_url('homecontroller/delete/' . $row->id); ?>" onclick="alert('are you sure you want to delete this record')" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
 <?php endforeach;?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
