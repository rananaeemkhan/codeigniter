<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow">
                    <div class="card-header">
                        <h5>Product Record</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url() . 'procutcontroller/saverecord'; ?>" method="POST">
                        <div class="row">
                          <div class="col-lg-12 mb-2">
                                <div class="form-group">
                                    <label for="">User Name</label>
                                        <select class="form-select form-select-md" aria-label=".form-select-lg example" name="name">

                                            <option selected>select name</option>
                                            <?php foreach ($get_user as $row): ?>
                                                <option value="<?php echo $row->id; ?>">
                                                <?php echo $row->user_name; ?></option>
                                                <?php endforeach;?>
                                                <small><?php echo form_error('user_name'); ?></small>
                                        </select>
                                </div>
                            </div>
                            <div class="col-md-12 mb-2">
                                <div class="form-group">
                                    <label for="">product Item</label>
                                    <input type="text" name="item" class="form-control" placeholder="Enter product Item">
                                    <small><?php echo form_error('item'); ?></small>
                                </div>
                            </div>
                            <div class="col-md-12 mb-4">
                                <div class="form-group">
                                    <label for="">Product Price</label>
                                    <input type="number" name="price" class="form-control" placeholder="Enter product price">
                                    <small><?php echo form_error('price'); ?></small>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-info px-5">Submit</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>