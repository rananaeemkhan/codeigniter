<?php include 'template/header.php';?>
<?php include 'template/navbar.php';?>
<?php include 'template/footer.php';?>

<div class="py5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 pt-2">
                <?php if ($this->session->flashdata('status')): ?>
                    <div class="alert alert-success">
                        <?=$this->session->flashdata('status');?>
                    </div>
                <?php endif?>
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-10">
                                <h5>Product Page</h5>
                            </div>
                            <div class="col-md-2 px-4">
                            <a href="<?php echo base_url() . 'addrecord'; ?>" class="btn btn-info btn-sm">Add Record</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>product_id</th>
                                <th>user_id</th>
                                <th>user_name</th>
                                <th>item</th>
                                <th>price</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <?php foreach ($record as $row): ?>
                            <tr>
                                <td><?php echo $row->product_id ?></td>
                                <td><?php echo $row->name ?></td>
                                <td><?php echo $row->user_name ?></td>
                                <td><?php echo $row->item ?></td>
                                <td><?php echo $row->price ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('procutcontroller/editrecord/' . $row->product_id); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('procutcontroller/delete/' . $row->product_id); ?>" class="btn btn-danger btn-sm" onclick="alert('are you sure you want to delete this record')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                </td>
                            </tr>
                            <?php endforeach;?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>