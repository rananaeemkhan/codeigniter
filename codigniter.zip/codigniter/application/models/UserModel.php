<?php
defined('BASEPATH') or exit('No direct script access allowed');

class UserModel extends CI_Model
{

    // for login data
    public function loginUser($data)
    {
        $this->db->select('*');
        $this->db->where('email', $data['email']);
        $this->db->where('password', $data['password']);
        $this->db->from('users');
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }
    // insert registration data into data base
    public function registerUser($data)
    {
        return $this->db->insert('users', $data);
    }

    // fetch all data from database users table
    public function gethomepage()
    {
        $query = $this->db->get('users');
        return $query->result();

    }
    // fetch data by id for edit from database in users table by Id

    public function editpage($id)
    {
        $query = $this->db->get_where('users', ['id' => $id]);
        return $query->row();
    }

    // query for update the data in database and form also

    public function updatepage($data, $id)
    {
        return $this->db->update('users', $data, ['id' => $id]);
    }
    public function daletepage($id)
    {
        return $this->db->delete('users', ['id' => $id]);
    }

}
