<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ProductModel extends CI_Model
{
    // this function get dropdown values in 'users' table on the page of addproduct
    public function getusers()
    {
        $query = $this->db->get('users');
        return $query->result();
    }

    public function recordUser($data)
    {
        return $this->db->insert('product', $data);
    }
    // this function fetch the data on database

    public function showdata()
    {

        $this->db->select("p.*, u.*");
        $this->db->from('users u');
        $this->db->join('product p', 'u.id = p.name');
        $query = $this->db->get();
        return $query->result();

    }

    // this function edit the data on database

    public function editproduct($product_id)
    {
        $query = $this->db->get_where('product', ['product_id' => $product_id]);
        return $query->row();
    }

    // this function update the data on database

    public function updatepage($data, $product_id)
    {
        return $this->db->update('product', $data, ['product_id' => $product_id]);

        // $this->db->update("p.*, u.*");
        // $this->db->from('users u');
        // $this->db->join('product p', 'u.id = p.name');
        // $query = $this->db->set();
        // return $query->result();
    }
    // for deopdown values

    public function valuesdrop()
    {
        $query = $this->db->get('users');
        return $query->result();
    }
    // this function dalete the data on database

    public function daletepage($product_id)
    {
        return $this->db->delete('product', ['product_id' => $product_id]);
    }
}
