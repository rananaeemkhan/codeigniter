<?php include 'template/header.php';?>
<?php include 'template/footer.php';?>

    <nav class="navbar navbar-expand-lg navbar-light bg-dark text-light">
  <div class="container-fluid">
    <div class="col-lg-3">
    <h5 class=" px-5 text-capitalize">my codeigniter project</h5>
    </div>
    <div class="col-lg-3"></div>
    <div class="col-lg-6">
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item">
            <a class="nav-link text-light active" aria-current="page" href="homepage">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link text-light" href="userpage">User-Page</a>
            </li>
            <li class="nav-item">
            <a class="nav-link text-light" href="showingdata">Product-Page</a>
            </li>
           <?php if (!$this->session->has_userdata('authenticated')) {?>
            <li class="nav-item">
            <a class="nav-link text-light" href="register">Register</a>
            </li>
            <li class="nav-item">
            <a class="nav-link text-light" href="login">Login</a>
            </li>
            <?php }?>

            <?php if ($this->session->has_userdata('authenticated') == true) {?>
            <li class="nav-item dropdown px-4">
                <span class="nav-link bg-info fw-bold text-dark px-4" href="#"><?php echo $this->session->userdata('user_name'); ?>
                </span>
           </li>
           <li class="nav-item dropdown px-4">
            <a class="nav-link text-light bg-danger px-4 fw-bold text-light f-large" href="<?=base_url('logoutcontroller/logout');?>">Logout</a>
           </li>
           <?php }?>

           </ul>
        </div>
    </div>
    </div>
</nav>
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>" ></script>
<script src="<?php echo base_url("assets/js/bootstrap.js"); ?>" ></script>
</body>
</html>