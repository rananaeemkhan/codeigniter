<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>" ></script>
<script src="<?php echo base_url("assets/js/bootstrap.js"); ?>" ></script>
</body>
</html>